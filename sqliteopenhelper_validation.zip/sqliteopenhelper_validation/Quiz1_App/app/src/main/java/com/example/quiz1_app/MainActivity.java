package com.example.quiz1_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import static com.example.quiz1_app.first_fragment.EMAIL;
import static com.example.quiz1_app.first_fragment.PASSWORD;
import static com.example.quiz1_app.first_fragment.STUDENTID;
import static com.example.quiz1_app.first_fragment.STUDENTNAME;

public class MainActivity extends AppCompatActivity {

    databaseHelper databaseHelper;
    public static FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmentManager = getSupportFragmentManager();

        if(findViewById(R.id.frame_container) != null){
            if(savedInstanceState != null){
                return;
            }

            FragmentTransaction ft = fragmentManager.beginTransaction();
            first_fragment form = new first_fragment();

            ft.add(R.id.frame_container, form, null).addToBackStack(null);
            ft.commit();

            databaseHelper = new databaseHelper(this);
            databaseHelper.addUser(STUDENTNAME,EMAIL,STUDENTID,PASSWORD);

        }

    }

}
