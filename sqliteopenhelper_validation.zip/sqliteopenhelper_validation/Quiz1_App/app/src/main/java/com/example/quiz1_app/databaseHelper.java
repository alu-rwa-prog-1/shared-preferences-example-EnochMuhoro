package com.example.quiz1_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class databaseHelper extends SQLiteOpenHelper {

//    define the database name
    public static final String database_name = "my_database";
//    define the database version
    public static final int database_version = 1;
//    Define the table
    public static final String table_name = "mytable";
    public static final String student_id = "id";
    public static final String student_name = "name";
    public static final String email = "email";
    public static final String password = "password";


    public databaseHelper(@Nullable Context context) {
        super(context, database_name, null, database_version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_LOGIN_TABLE = "CREATE TABLE " + table_name + "("
                + student_id + " INTEGER PRIMARY KEY,"
                + email + " TEXT,"
                + password + " TEXT UNIQUE" + ")";
        db.execSQL(CREATE_LOGIN_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists " + table_name);
        onCreate(db);
    }

    public void addUser(String name, String mail, String id, String pword) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(student_name, name); // Name
        values.put(email, mail); // Email
        values.put(student_id, id); // Email
        values.put(password, pword); // Created At

        // Inserting Row
        db.insert(table_name , null, values);
        db.close(); // Closing database connection
    }
}
