package com.example.quiz1_app;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class first_fragment extends Fragment {

    Button button;
    EditText estudentname, gmail, estudentpassword, estudentid;

    public static final String MYPREFERENCES = "myprefs";
    public static final String STUDENTNAME = "stdname";
    public static final String STUDENTID = "stdid";
    public static final String PASSWORD = "pword";
    public static final String EMAIL = "mail";

    SharedPreferences sharedPreferences;

    public first_fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragfirst_fragment, container, false);

        estudentname = view.findViewById(R.id.studentname);
        gmail = view.findViewById(R.id.email);
        estudentpassword = view.findViewById(R.id.password);
        estudentid = view.findViewById(R.id.studentid);

        sharedPreferences = getActivity().getSharedPreferences(MYPREFERENCES, Context.MODE_PRIVATE);

        getSavedData();

        button = view.findViewById(R.id.add_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // before performing any action check if the input fields are empty
                if(TextUtils.isEmpty(estudentid.getText().toString())) {
                    estudentid.setError("Please enter student id");
                }
                if(TextUtils.isEmpty(estudentname.getText().toString())) {
                    estudentname.setError("Please enter student name");
                }
                if(TextUtils.isEmpty(estudentpassword.getText().toString())) {
                    estudentpassword.setError("Please enter student password");
                }
                if(TextUtils.isEmpty(gmail.getText().toString())) {
                    gmail.setError("Please enter your email");
                }
                else {
                    // if everything is filled, go ahead and save the data first.
                    savedata();
                    Fragment fragment = new second_fragment();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.frame_container, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            }
        });

        return view;
    }

    public void savedata(){
        // save data from the edit text
        // I will use the different inout fields to get my information from the user and change it to string
        String n = estudentname.getText().toString();
        String e = gmail.getText().toString();
        String id_no = estudentid.getText().toString();
        String pass = estudentpassword.getText().toString();

        // use the sharedpreference editor to save the information
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(STUDENTNAME, n);
        editor.putString(PASSWORD, pass);
        editor.putString(EMAIL, e);
        editor.putString(STUDENTID, id_no);
    }

    public void getSavedData(){
        // get the saved data and put them back in the text editors
        if (sharedPreferences.contains(STUDENTNAME)){
            // use sharedpreferences to get information that was saved
            String got_n = sharedPreferences.getString(STUDENTNAME, "");
            String got_e = sharedPreferences.getString(EMAIL, "");
            String got_pass = sharedPreferences.getString(PASSWORD, "");
            String got_id_no = sharedPreferences.getString(STUDENTID, "");

            // use the respective text editors to to the information saved
            estudentname.setText(got_n);
            gmail.setText(got_e);
            estudentpassword.setText(got_pass);
            estudentid.setText(got_id_no);
        }
    }
}

